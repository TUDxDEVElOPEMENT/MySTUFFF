import socket
import concurrent.futures
from termcolor import colored
import time
import signal
import os

host = input("(*) Enter hostname: ")

def alhost(host):
    try:
        hostIP = socket.gethostbyname(host)
        print("Scan Results for: " + colored(hostIP, 'magenta'))
        print("<+>")
        print("PRESS "+ colored("!CTRL+C!", 'red') +" IF IT TAKES FOREVER \n")
    except:
        print("Unknown Host: " + host)
        os._exit(0)

alhost(host)

def portscan(port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    result = sock.connect_ex((host, port))
    if result == 0:
        try:
            service = socket.getservbyport(port, "tcp")
            output = f"{colored('[', 'green')}{colored('+', 'white')}{colored(']', 'green')} {str(port):<5} : SERVICE: {colored(service, 'cyan')}"
            print(output)
            scanned_ports.append(port)  # Update the scanned_ports list
        except:
            pass
    sock.close()

scanning_interrupted = False

def signal_handler(signal, frame):
    global scanning_interrupted
    scanning_interrupted = True
    print(colored("\n[:-STOPPED-:]", 'red'))
    print(f"Scanned {colored(len(scanned_ports), 'yellow')} ports.")
    print(f"Total time taken: {colored(round(time.time() - start_time, 2), 'yellow')} seconds.")
    os._exit(0)

signal.signal(signal.SIGINT, signal_handler)

start_time = time.time()
scanned_ports = []

num_threads = 100

with concurrent.futures.ThreadPoolExecutor(max_workers=num_threads) as executor:
#Below u can change how much ports u want to scan |||
    tasks = [executor.submit(portscan, port) for port in range(1, 65536)]

    concurrent.futures.wait(tasks, return_when=concurrent.futures.FIRST_COMPLETED)

end_time = time.time()
duration = end_time - start_time

if scanning_interrupted:
    print("Scanning process was interrupted by user!")
else:
    print("\nScanning completed successfully!")
    print(f"Scanned {colored(len(scanned_ports), 'yellow')} ports.")
    print(f"Total time taken: {colored(round(duration, 2), 'yellow')} seconds.") 
