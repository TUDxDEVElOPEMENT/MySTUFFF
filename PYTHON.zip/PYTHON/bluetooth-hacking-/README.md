# bluetooth-hacking-
This repository contains scripts in python from discovering bluetooth to taking over the bluetooth connections.

you can find all the documents of the repo as well as other hacks in this blog.
<table style="margin: 0px auto;">
<thead>
    <tr>
        <th>SECURING SYSTEM</th>
        <th>BLUETOOTH ATTACKS</th>
        <th>STEALING AND SNIFFING ATTACKS</th>
        <th>KALI LINUX HACKING COMMANDS CHEATSHEET</th>
        <th>TROJAN AND BACKDOORS</th>
        <th>DICTIONARY AND BURTEFORCING ATTACKS</th>
        <th>MAN IN THE MIDDLE ATTACKS</th>

    </tr>
</thead>
<tbody>
<tr>
    <td>1. <a href='https://www.codexpace.in/2021/10/signverify.html'>Sign & Verify message</a></td>
    <td>1. <a href="https://www.codexpace.in/2022/07/bluetooth-scanner-with-python.html">Bluetooth discovery</a></td>
    <td>1. <a href="https://www.codexpace.in/2022/06/stealing-wifi-passwords-with-python.html">Stealing saved wifi password from windows</a></td>
    <td>1. <a href="https://www.codexpace.in/2022/02/hacking-with-kali-cheatsheet.html">Hacking commands with Kali Linux </a></td>
    <td>1. <a href='https://www.codexpace.in/2021/11/command-control-trojan-with-python.html'>Command and Control Trojan</a></td>
    <td>1. <a href="https://www.codexpace.in/2022/03/dictionary-attacks.html">Dictionary Attack</a></td>
    <td>1. <a href="https://www.codexpace.in/2022/03/man-in-browser.html">Man in Browser Attack</a></td>


</tr>
<tr>
    <td>2. <a href='https://www.codexpace.in/2022/02/sandbox-detection.html'>SandBox Detection</a></td>
    <td>2. <a href="https://www.codexpace.in/2022/07/sdpservice-discovery-protocol-browser.html">Bluetooth SDP browsing</a></td>
    <td>2. <a href="https://www.codexpace.in/2022/04/sniffer-with-no-filter.html">Sniffing packets</a></td>
    <td></td>
    <td>2. <a href="https://www.codexpace.in/2022/06/revershell-with-python.html">Reverse shell in python</a></td>

</tr>
<tr>
    <td>3. <a href='https://www.codexpace.in/2022/03/tcp-proxy.html'>TCP Proxy</a></td>
    <td>3. <a href="https://www.codexpace.in/2022/07/obex-object-exchange.html">Bluetooth OBEX</a></td>
    <td>3. <a href="https://www.codexpace.in/2022/04/sniffer-for-email-credentials.html">Email Credential sniffers </a></td>
    <td></td>
    <td>3. <a href='https://www.codexpace.in/2021/11/python-keylogger.html'>Keylogger</a></td>

</tr>
<tr>
    <td></td>
    <td>4. <a href="https://www.codexpace.in/2022/07/rcomm-channel-scanner.html">Bluetooth RCOMM channel scanner</a></td>
    <td></td>
    <td></td>
    <td>4. <a href='https://www.codexpace.in/2022/01/screenshot-with-python.html'>Screenshot with Python</a></td>

</tr>
<tr>
    <td></td>
    <td>5. <a href="https://www.codexpace.in/2022/07/blue-bug-exploit.html">Blue Bug Exploit</a></td>
    <td></td>
    <td></td>
    <td>5. <a href='https://www.codexpace.in/2022/06/revershell-with-python.html'>Backdoor with Python</a></td>

</tr>
<tr>
    <td></td>
    <td>6. <a href="https://www.codexpace.in/2022/07/blue-snarf-exploit.html">Blue Snarf Exploit</a></td>
</tr>
<tr>
    <td></td>
    <td>7. <a href="https://www.codexpace.in/2022/07/bluetooth-spoofing.html">Bluetooth spoofing</a></td>
</tr>
    <tr>
    <td></td>
    <td>8. <a href="https://www.codexpace.in/2022/07/bluetooth-sniffing.html">Bluetooth sniffing</a></td>
</tr>
    

</tbody>
</table>
