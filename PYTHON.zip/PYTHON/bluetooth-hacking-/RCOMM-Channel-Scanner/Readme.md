you can check the documentation / explanation of code in below link.</br>
<a href="https://www.codexpace.in/2022/07/rcomm-channel-scanner.html" title="Go to project documentation"><img src="https://img.shields.io/badge/view-Documentation-blue?style=for-the-badge" alt="view - Documentation"></a>
</div>
