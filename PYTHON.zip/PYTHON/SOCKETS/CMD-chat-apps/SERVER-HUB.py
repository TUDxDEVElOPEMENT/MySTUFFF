import socket
import threading
import os
import sys

class Server:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.clients = []
        self.client_names = []
        self.running = True

    def start(self):
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen()

        print(f"Server started listening on {self.host}:{self.port}")

        accept_thread = threading.Thread(target=self.accept_clients)
        accept_thread.start()

        command_thread = threading.Thread(target=self.handle_commands)
        command_thread.start()

    def accept_clients(self):
        while self.running:
            client_socket, address = self.server_socket.accept()
            client_name = client_socket.recv(1024).decode()
            self.clients.append(client_socket)
            self.client_names.append((client_name, address))
            print(f"{client_name} connected. ({address[0]}:{address[1]})")

            self.send_message_to_all(f"{client_name} joined the chat.")

            client_thread = threading.Thread(target=self.handle_client, args=(client_socket,))
            client_thread.start()

    def handle_client(self, client_socket):
        while self.running:
            try:
                message = client_socket.recv(1024).decode()
                if message == "/exit":
                    self.disconnect_client(client_socket)
                    break
                self.send_message_to_all(f"{self.get_client_name(client_socket)}: {message}")
            except ConnectionResetError:
                self.disconnect_client(client_socket)
                break

    def disconnect_client(self, client_socket):
        client_name = self.get_client_name(client_socket)
        client_socket.close()
        self.clients.remove(client_socket)
        self.client_names = [(name, addr) for name, addr in self.client_names if name != client_name]
        print(f"{client_name} left the server")

    def send_message_to_all(self, message):
        for client in self.clients:
            client.send(message.encode())

    def get_client_name(self, client_socket):
        index = self.clients.index(client_socket)
        return self.client_names[index][0]

    def show_connected_users(self):
        print("Connected Users:")
        for name, address in self.client_names:
            print(f"Username: {name}\nAddress: {address[0]} : {address[1]}\n")

    def show_help(self):
        print("Available commands:")
        print("users - Show connected users")
        print("clear - Clear the screen")
        print("shutdown - Stop the server")

    def handle_commands(self):
        while self.running:
            command = input(">>> ").strip()
            if command == "":
                continue
            if command == "users":
                self.show_connected_users()
            elif command == "clear":
                os.system('clear' if os.name == 'posix' else 'cls')
            elif command == "shutdown":
                self.shutdown()
                break
            elif command == "help":
                self.show_help()
            else:
                print("Invalid command. Type 'help' to see available commands.")

    def shutdown(self):
        self.running = False
        for client in self.clients:
            client.close()
        self.server_socket.close()

if __name__ == "__main__":
    host = '127.0.0.1'  # Enter your server's host IP address here
    port = 55555  # Enter your server's port number here
    server = Server(host, port)
    server.start()
 
