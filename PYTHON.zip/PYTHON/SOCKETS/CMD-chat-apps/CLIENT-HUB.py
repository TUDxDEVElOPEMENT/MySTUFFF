import socket
import threading

class Client:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def start(self):
        self.client_socket.connect((self.host, self.port))
        print("Connected to the server.")

        username = input("Enter your username: ")
        self.client_socket.send(username.encode())

        print(f"Welcome to the chat room, {username}! Say hello to everyone.")
        print("Type '\\help' to see available commands.")

        self.receive_thread = threading.Thread(target=self.receive_messages)
        self.receive_thread.start()

        self.send_messages()

    def receive_messages(self):
        while True:
            try:
                message = self.client_socket.recv(1024).decode()
                if not message:
                    print("Disconnected from the server.")
                    break
                print(message)
            except OSError as e:
                print(f"Error occurred: {e}")
                break

    def send_messages(self):
        while True:
            message = input("> ")
            if message == "":
                continue
            elif message == "\\exit":
                self.client_socket.send("/exit".encode())
                self.client_socket.close()
                self.receive_thread.join()
                print("Bye bye, disconnected from the server.")
                exit()
            elif message == "\\clear":
                print("\033[H\033[J")  # Clear the terminal screen
            elif message == "\\help":
                self.show_help()
            else:
                self.client_socket.send(message.encode())

    def show_help(self):
        print("Available commands:")
        print("\\clear - Clear the screen")
        print("\\exit - Exit the chat room")

if __name__ == "__main__":
    host = '127.0.0.1'  # Enter your server's host IP address here
    port = 55555  # Enter your server's port number here
    client = Client(host, port)
    client.start()
 
