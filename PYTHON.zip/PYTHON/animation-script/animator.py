import time
import os

# Read frames from the animation.txt file
with open('animation.txt', 'r') as file:
    frames = file.read().split('\n\n')  # Assumes frames are separated by two newlines

# Define the time delay (in seconds) between frames
delay = 0.2  # Adjust this value to change the animation speed

# Clear the screen (use 'cls' for Windows, 'clear' for macOS and Linux)
clear_screen = lambda: os.system('cls' if os.name == 'nt' else 'clear')

# Infinite loop to display the animation
while True:
    for frame in frames:
        clear_screen()
        print(frame)
        time.sleep(delay)
 
