import time
import random
import sys
import os

def clear_terminal():
    sys.stdout.write("\033[H\033[J")

def get_random_coordinates(rows, columns):
    x = random.randint(0, columns - 10)  # Adjust for the length of the time string
    y = random.randint(0, rows - 1)
    return x, y

def get_current_time():
    current_time = time.strftime("%I:%M %p")  # 12-hour clock with AM/PM
    return current_time

try:
    while True:
        # Clear the terminal
        clear_terminal()

        # Get terminal dimensions
        rows, columns = map(int, os.popen('stty size', 'r').read().split())

        # Generate random coordinates
        x, y = get_random_coordinates(rows, columns)

        for _ in range(10):  # 10 steps for a smoother effect
            clear_terminal()
            current_time = get_current_time()
            sys.stdout.write("\033[{};{}H{}".format(y, x, current_time))
            sys.stdout.flush()
            time.sleep(0.09)

except KeyboardInterrupt:
    pass
 
