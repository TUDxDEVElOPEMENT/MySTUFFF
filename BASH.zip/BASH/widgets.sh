#!/bin/bash
while :
do
 clear
 toilet -f future --filter border --gay Welcome to Widgets
 sleep 1
 echo -e  "by \e[31;1mSHANKS\e[0m"
 echo ""
 echo -e "\e[3m@ Widgets we have :-\e[0m"
 echo ""
 echo -e "\e[1m(1) Clock       (4) G-search\e[0m"
 echo -e "\e[1m(2) Matrix	(5) Telehack\e[0m"
 echo -e "\e[1m(3) Fortune	(6) X.O-game\e[0m"
 echo ""
 echo -e "\e[1m(10) For running all the above widgets\e[0m"
 echo -e "\e[1m(0)\e[0m\e[4m To exit the program\e[0m"
 echo ""
 read -rep  $'Enter the widget number - : ' input
 echo ""
 if [ $input = "1" ]; then
	echo "Started clock"
	xterm -T TIME -geometry 37x7-100+60 -e bash /home/shanks/BASH/widgets-source/clock.sh&

 elif [ $input = "2" ]; then
	echo "Started matrix"
	xterm -T MATRIX -geometry 37x9-600+250 -e bash /home/shanks/BASH/widgets-source/cmatrix.sh&
	echo "If stopped hit ctrl + c"
	sleep 3

 elif [ $input = "3" ]; then
        echo "Started fortune"
	xterm -T FORTUNE -geometry 60x10-900+390 -e bash /home/shanks/BASH/widgets-source/fortune.sh&

 elif [ $input = "4" ]; then
        echo "G-search"
	xterm -T GOOGLER -geometry 80x11-200+500 -e bash /home/shanks/BASH/widgets-source/g-search.sh&

 elif [ $input = "5" ]; then
        echo "Telehack"
        xterm -T TELEHACK -geometry 70x15-100+200 -e bash /home/shanks/BASH/widgets-source/telehack.sh&

 elif [ $input = "6" ]; then
        echo "X.0-game"
	xterm -T X.O -geometry 30x10-400+100 -e bash /home/shanks/BASH/widgets-source/xo.sh&

 elif [ $input = "10" ]; then
        echo "Running all the widgets"
	xterm -T X.O -geometry 30x10-400+100 -e bash /home/shanks/BASH/widgets-source/xo.sh&
	xterm -T TELEHACK -geometry 70x15-100+200 -e bash /home/shanks/BASH/widgets-source/telehack.sh&
	xterm -T GOOGLER -geometry 80x11-200+500 -e bash /home/shanks/BASH/widgets-source/g-search.sh&
	xterm -T FORTUNE -geometry 60x10-900+390 -e bash /home/shanks/BASH/widgets-source/fortune.sh&
	xterm -T MATRIX -geometry 37x9-600+250 -e bash /home/shanks/BASH/widgets-source/cmatrix.sh&
	xterm -T TIME -geometry 37x7-100+60 -e bash /home/shanks/BASH/widgets-source/clock.sh&
	echo "Process Table :-"
	echo ""
	ps
	sleep 6
	exit

 elif [ $input = "0" ];then
	exit

 else
	echo -e "Please enter the number which are given above only and try again"

 fi

done;
