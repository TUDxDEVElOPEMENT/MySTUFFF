#!bin/sh
if test -z "$1"
then
	clear
	echo ""
	read -rep  $'Name of the file you need to find - : ' filename
	dirname=$(pwd | grep -o "\w*-*$")
	search=$(tree | grep "$filename" | tr -d "│   ├──")

	if test -z "$search"
	then
     	 echo ""
     	 echo -e "File is \e[1;41mNOT HERE\e[0m"
      	 echo -e "\e[32;1mTip - (Try running me in your base folder)\e[0m"
         echo -e "\e[37;1mYou are currently running me in this folder\e[0m: '$dirname'"
	else
      	 filepath=$(find . -name $filename)
      	 echo ""
      	 echo -e "\e[1;44mFile is here !\e[0m"
      	 echo -e "\e[33;1mFile path -:\e[0m $filepath"
	fi
else
	clear
	echo ""
	dirname=$(pwd | grep -o "\w*-*$")
	search=$(tree | grep "$1" | tr -d "│   ├──")

	if test -z "$search"
	then
	      echo ""
	      echo -e "File is \e[1;41mNOT HERE\e[0m"
	      echo -e "\e[32;1mTip - (Try running me in your base folder)\e[0m"
	      echo -e "\e[37;1mYou are currently running me in this folder\e[0m: '$dirname'"
	else
	      filepath=$(find . -name $1)
	      echo ""
	      echo -e "\e[1;44mFile is here !\e[0m"
	      echo -e "\e[33;1mFile path -:\e[0m $filepath"
	fi
fi
