#!bin/bash

while true ;
do
    clear
    echo ""
    fortune=$(fortune -s)
    echo -e  "$fortune" | lolcat;
    sleep 13;
    clear&
done
