#!/bin/bash
ssh -p 6668 live@telehack.com
