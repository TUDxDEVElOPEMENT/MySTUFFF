#!/bin/bash
while :
do
cmatrix 
done;
