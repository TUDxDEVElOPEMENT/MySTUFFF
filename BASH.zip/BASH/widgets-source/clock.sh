#!bin/bash

#xterm -T TIME -geometry 41x8-80+60 -e bash clock.sh

 while true;
 do
    tput clear;
    date +"%H : %M : %S " | toilet -f future --filter border | lolcat;
    COLUMNS=$(tput cols)
    title=$(echo -e "      \e[37m F O C U S\e[0m   \e[31m S H A N K S\e[0m")
    printf "%*s\n" $(((${#title}+$COLUMNS)/2)) "$title"
    sleep 5;
 done;
