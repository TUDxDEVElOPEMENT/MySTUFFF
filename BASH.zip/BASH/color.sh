#!/bin/bash

#Watashi wa shanks

#Created By SHANKS! live@telehack.com
#@Copyright since 2006 all rights and reserves Inc.
#Don't mind if you notice the colour spelling wrong it was intentional , we are programmers dude !
clear
color="\033[38;5;";nb=0;nb2=1
echo -e "\e[37;1m    ALL RGB COLOURS\e[0m"
sleep 2
echo ""
while [ $nb -lt 255 ] ; do printf "$color${nb}m: %3d \033[0m" ${nb} ; if [ $nb2 -eq 10 ] ; then nb2=0 ; echo ""; fi ; nb=`expr $nb + 1`; nb2=`expr $nb2 + 1` ; done
echo ""
echo ""
echo -e "\e[4mUsage:\e[0m"
echo "Foreground: \e[31;1m" " : Use with the above RGB codes = \e[38;5;#m"
echo "Background: \e[1;41m" " : Use with the above RGB codes = \e[48;5;#m"
echo ""
echo -e "\e[4mForeground Colors:\e[0m"
echo -e "\e[30m30\e[0m"
echo -e "\e[31m31\e[0m"
echo -e "\e[32m32\e[0m"
echo -e "\e[33m33\e[0m"
echo -e "\e[34m34\e[0m"
echo -e "\e[35m35\e[0m"
echo -e "\e[36m36\e[0m"
echo -e "\e[37m37\e[0m"
echo ""
echo -e "\e[4mBackground Colors:\e[0m"
echo -e "\e[1;41m41\e[0m"
echo -e "\e[1;42m42\e[0m"
echo -e "\e[1;43m43\e[0m"
echo -e "\e[1;44m44\e[0m"
echo -e "\e[1;45m45\e[0m"
echo -e "\e[1;46m46\e[0m"
echo -e "\e[1;47m47\e[0m"
echo ""
echo ""
echo -e "\e[4mFont Codes:\e[0m"
echo ""
echo "  \e[0m  Reset Style"
echo "  \e[1m  Bold"
echo "  \e[2m  Low Intensity"
echo "  \e[3m  Italic"
echo "  \e[4m  Underline"
echo "  \e[5m  Blink"
echo "  \e[7m  Inverse"
echo "  \e[8m  Invisible"
echo "  \e[9m  Strikethrough"
echo ""
echo ""
echo ""
sleep 3
read -rep $'Would u like to see examples(y/n): ' usr
if [ $usr = "y" ]
then
	clear
 	spinner=( "############ " "############" "\e[31;1mS\e[0m###########" "\e[31;1mKS\e[0m##########" "\e[31;1mNKS\e[0m#########" "\e[31;1mANKS\e[0m########" "\e[31;1mHANKS\e[0m########" "\e[31;1mSHANKS\e[0m#######" "#\e[31;1mSHANKS\e[0m#####" "##\e[31;1mSHANKS\e[0m####" "###\e[31;1mSHANKS\e[0m###" "####\e[31;1mSHANKS\e[0m##" "#####\e[31;1mSHANKS\e[0m#" "######\e[31;1mSHANKS\e[0m" "#######\e[31;1mSHANK\e[0m" "########\e[31;1mSHAN\e[0m" "#########\e[31;1mSHA\e[0m" "##########\e[31;1mSH\e[0m" "###########\e[31;1mS\e[0m" "############" );
        count(){
          spin &
          pid=$!

          for i in `seq 1 6` 
          do
            sleep 1;
          done

          kill $pid
        }

        spin(){
          while [ 1 ]
          do
            for i in ${spinner[@]};
            do
              echo -e -ne "\r$i";
              sleep 0.11;
            done;
          done
        }

        count
	echo ""
	clear
	echo -e "\e[37;1m}! EXAMPLES !{\e[0m"
	sleep 2
	clear
  echo -e "\e[37;1m}! EXAMPLES !{\e[0m"
	echo ""
  echo -e "{\e[36;1m-e is MUST\e[0m}"
  echo ""
  echo -e "\e[38;5;226mHow to add basic color in text :-\e[0m"
	echo ""
	echo 'Syntax: echo -e "\e[36;1m Hello World \e[0m"'
	echo -e "Output: \e[36m Hello World \e[0m"
	echo ""
  echo -e "\e[38;5;226mHow to add basic color with FONT CODES :-\e[0m"
	echo ""
	echo 'Syntax: echo -e "\e[37;3m Hello World \e[0m"'
	echo -e "Output: \e[37;3m Hello World \e[0m"
	echo ""
	echo -e "\e[38;5;226mHow to add RGB colors in text :-\e[0m"
	echo 'Syntax: echo -e "\e[38;5;117m Hello World \e[0m"'
	echo -e "Output: \e[38;5;117m Hello World\e[0m"
	echo ""
  echo -e "\e[38;5;226mHow to add background color :-\e[0m"
	echo ""
	echo 'Syntax: echo -e "\e[1;41m Hello Wrold \e[0m"'
	echo -e "Output: \e[1;41m Hello World\e[0m"
  echo -e "\e[38;5;226mHow to add RGB background color :-\e[0m"
  echo ""
  echo 'Syntax: echo -e "\e[48;5;53m Hello Wrold \e[0m"'
  echo -e "Output: \e[48;5;53m Hello World\e[0m"
  sleep 5
	read -rep  $'\nWould u like to practice yourself in our editor (y/n): ' editor
  if [ $editor == "y" ]
  then
    echo ""
    echo "{If you want to execute your code just press CTRL+D on a empty line}"
    echo ""
    while :
    do
	    echo ""
	    echo -e "\e[38;5;87mType your code here :-\e[0m"
	    echo ""
	    touch yourEXAMPLE.sh
	    chmod +x yourEXAMPLE.sh
	    cat > yourEXAMPLE.sh
	    echo ""
	    echo -e "\e[30;1mOutput :-\e[0m"
	    bash yourEXAMPLE.sh
	    rm yourEXAMPLE.sh
	    echo -e "\e[0m"
	    sleep 5
	    clear
	    echo "{If u want to exit this program press CTRL+C}"
    done
  else
    exit
  fi
else
	exit
fi
