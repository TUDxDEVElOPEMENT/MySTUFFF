read -rep  $'\n - WHat is that - : ' ip
$ip
